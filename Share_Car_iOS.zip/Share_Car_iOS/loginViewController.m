//
//  loginViewController.m
//  ShareCare
//
//  Created by Wissem Rezgui on 20/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import "loginViewController.h"
#import "PAWActivityView.h"
#import "AdsViewController.h"
#import "Reachability.h"


@interface loginViewController ()
{
    Reachability *internetReachableFoo;
}
@end

@implementation loginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
        // Do any additional setup after loading the view.
    [self testInternetConnection];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)LogInFaceBookkPressed:(id)sender {
    NSArray *permissionsArray = @[ @"user_about_me", @"user_interests", @"user_relationships", @"user_birthday", @"user_location", @"user_relationship_details"];
    
    /*This method delegates to the Facebook SDK to authenticate
     
     the user, and then automatically logs in (or creates, in the case where it is a new user) a PFUser. */
    
    [PFFacebookUtils logInWithPermissions:permissionsArray block:^(PFUser *user, NSError *error) {
        
        
        if (!user) {
            
            if (!error) {
                
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Log In Error" message:@"The Facebook login was cancelled." delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Dismiss", nil];
                
                
                
                [alert show];
                
            } else {
                NSLog(@"____________________ ");
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Log In Error" message:[error description] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Dismiss", nil];
                
                [alert show];
                
            }
            
        } else {
            [self updateUserInformation];
            
            
        }
        
    }];
    
}

- (IBAction)Authentif:(id)sender {
    [self authentification];
}
-(void)updateUserInformation

{
    // Send request to Facebook
    
    FBRequest *request = [FBRequest requestForMe];
    
    [request startWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
        
        // handle response
        
        if (!error) {
            
            // Parse the data received
            
            NSDictionary *userDictionary = (NSDictionary *)result;
            
            NSMutableDictionary *userProfile = [[NSMutableDictionary alloc] initWithCapacity:7];
            
            if (userDictionary[@"name"]) {
                
                userProfile[@"name"] = userDictionary[@"name"];
                
            }
            
            if (userDictionary[@"first_name"]) {
                
                userProfile[@"first_name"] = userDictionary[@"first_name"];
                
            }
            
            if (userDictionary[@"location"][@"name"]) {
                
                userProfile[@"location"] = userDictionary[@"location"][@"name"];
                
            }
            
            if (userDictionary[@"gender"]) {
                
                userProfile[@"gender"] = userDictionary[@"gender"];
                
            }
            
            if (userDictionary[@"birthday"]) {
                
                userProfile[@"birthday"] = userDictionary[@"birthday"];
                
            }
            
            if (userDictionary[@"interested_in"]) {
                
                userProfile[@"interested_in"] = userDictionary[@"interested_in"];
                
            }
            
            [[PFUser currentUser] setObject:userProfile forKey:@"profile"];
            
            [[PFUser currentUser] saveInBackground];
              NSLog(@"Log with Succes");
            
        }
        
        else {
            
            NSLog(@"Error in Facebook Request %@", error);
            
        }
        
    }];
    
}
-(void) authentification {
    
    self.activityViewVisible = YES;
    [PFUser logInWithUsernameInBackground:_lbl_name.text password:_lbl_pass.text
                                    block:^(PFUser *user, NSError *error) {
                                        if (user) {
                                            // Do stuff after successful login.
                                            NSLog(@"login success!");
                                            
                                            self.activityViewVisible = NO;
                                            
                                            UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"listads"];
                                            
                                            [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
                                            
                                            // Present the view controller;
                                            [self presentViewController:settingsNC animated:YES completion:NULL];

                                            
                                        } else {
                                            // The login failed. Check error to see why
                                            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Authentification Failed"
                                                                    message:@"Please check your coordinated"
                                                                    delegate:self
                                                                    cancelButtonTitle:@"Ok"
                                                                    otherButtonTitles:nil, nil];
                                            [alertView show];

                                            self.activityViewVisible = NO;
                                        }
                                    }];
}

- (void)setActivityViewVisible:(BOOL)visible {
    if (self.activityViewVisible == visible) {
        return;
    }
    
    _activityViewVisible = visible;
    
    if (_activityViewVisible) {
        PAWActivityView *activityView = [[PAWActivityView alloc] initWithFrame:self.view.bounds];
        activityView.label.text = @"Logging in";
        activityView.label.font = [UIFont boldSystemFontOfSize:20.f];
        [activityView.activityIndicator startAnimating];
        
        _activityView = activityView;
        [self.view addSubview:_activityView];
    } else {
        [_activityView removeFromSuperview];
        _activityView = nil;
    }
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
    
}

- (void)testInternetConnection
{
    internetReachableFoo = [Reachability reachabilityWithHostname:@"www.google.com"];
    
    // Internet is reachable
    internetReachableFoo.reachableBlock = ^(Reachability*reach)
    {
        // Update the UI on the main thread
        dispatch_async(dispatch_get_main_queue(), ^{
           
        });
    };
    
    // Internet is not reachable
    internetReachableFoo.unreachableBlock = ^(Reachability*reach)
    {
        // Update the UI on the main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Network Connection"
                                                        message:@"Please check your Internet Connection"
                                                      delegate:self
                                                      cancelButtonTitle:@"Ok"
                                                      otherButtonTitles:nil, nil];
            [alertView show];
        });
    };
    
    [internetReachableFoo startNotifier];
}
@end
