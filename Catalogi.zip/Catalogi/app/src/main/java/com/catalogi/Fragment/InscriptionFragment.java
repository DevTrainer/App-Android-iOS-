package com.catalogi.Fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.catalogi.R;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

import java.io.ByteArrayOutputStream;


public class InscriptionFragment extends Fragment {

    public InscriptionFragment() {
        // Required empty public constructor
    }
    private OnFragmentInteractionListener mListener;
    private static final int CAMERA_REQUEST = 1888;
    ImageView ImageProfil;
    byte[] byteArray;
    ParseFile file;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.inscription_activity, container, false);

        final EditText username =(EditText) view.findViewById(R.id.username);
        final EditText email =(EditText) view.findViewById(R.id.email);
        final EditText password =(EditText) view.findViewById(R.id.password);
        final EditText phoneNumber =(EditText) view.findViewById(R.id.phone);
        final EditText adresse =(EditText) view.findViewById(R.id.adresse);
        ImageProfil =(ImageView) view.findViewById(R.id.imageProfile);
        Button confirmer =(Button) view.findViewById(R.id.confirm_inscription);
        confirmer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ParseUser user = new ParseUser();
                user.setUsername(username.getText().toString());
                user.setPassword(password.getText().toString());
                user.setEmail(email.getText().toString());
                user.put("phone", phoneNumber.getText().toString());
                user.put("adresse", adresse.getText().toString());
                user.put("image", file);
                user.signUpInBackground(new SignUpCallback() {
                    public void done(ParseException e) {
                        if (e == null) {
                           showHomeFragment(new CatalogueFragment());
                        } else {
                           showDialog(getActivity(),"Sign up failed","username has already taken,please choose another one","OK",null);
                            Log.e(""," error parse wissem :"+e);
                        }
                    }
                });
            }
        });
        ImageProfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            }
        });
        return view;

    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
           // mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


public interface OnFragmentInteractionListener {
    public void onMenuSelection(String menu_item);
}
    public void showHomeFragment(Fragment fragment) {

        Fragment home = fragment;
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction()

                .replace(R.id.container, home)
                .addToBackStack(home.getClass().getSimpleName())
                .commit();

    }
    private static AlertDialog showDialog(final Activity act, CharSequence title, CharSequence message, CharSequence buttonYes, CharSequence buttonNo) {
        final AlertDialog.Builder downloadDialog = new AlertDialog.Builder(act);
        downloadDialog.setTitle(title);
        downloadDialog.setMessage(message);
        downloadDialog.setPositiveButton(buttonYes, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        return downloadDialog.show();
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST && resultCode == getActivity().RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            ImageProfil.setImageBitmap(photo);
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            photo.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byteArray = stream.toByteArray();
            file = new ParseFile("profile.png",byteArray);
            file.saveInBackground();
        }
    }
}

