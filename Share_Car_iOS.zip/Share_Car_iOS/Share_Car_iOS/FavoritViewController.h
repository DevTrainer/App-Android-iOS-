//
//  FavoritViewController.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoritViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, strong) NSMutableIndexSet *optionIndices;
- (IBAction)SideBar:(id)sender;
@property  (strong,nonatomic) NSArray* listOffav;


@property (weak, nonatomic) IBOutlet UITableView *listfav;


@end
