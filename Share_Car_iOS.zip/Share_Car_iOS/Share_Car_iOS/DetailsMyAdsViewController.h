//
//  DetailsMyAdsViewController.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 01/12/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailsMyAdsViewController : UIViewController

@property  (strong,nonatomic) NSString* livingfrom;
@property (strong, nonatomic) NSString *roadOn;
@property (strong, nonatomic) NSString *goingto;
@property (strong, nonatomic) NSString *date;
@property (strong, nonatomic) NSString *time;

@property (strong, nonatomic) IBOutlet UILabel *livingfromm;
@property (strong, nonatomic) IBOutlet UILabel *roadon;
@property (strong, nonatomic) IBOutlet UILabel *gotoo;
@property (strong, nonatomic) IBOutlet UILabel *Datee;
@property (strong, nonatomic) IBOutlet UILabel *tim;

@end
