//
//  AppDelegate.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 26/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

