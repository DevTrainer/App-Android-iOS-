package com.catalogi.Fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.catalogi.Model.Product;
import com.catalogi.R;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Wissem on 02/11/15.
 */
public class ProductListFragment extends Fragment {

    public ProductListFragment() {

    }
    private OnFragmentInteractionListener mListener;
    public static String categorie;
    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter mAdapter;
    Product product;
    List<Product> productList;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_product_list, container, false);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        productList=new ArrayList<Product>();

        ParseQuery<ParseObject> query = ParseQuery.getQuery("Produit");
        query.whereEqualTo("categorie", categorie);
        query.findInBackground(new FindCallback<ParseObject>() {
            public void done(List<ParseObject> scoreList, ParseException e) {
                if (e == null) {
                    for (int i = 0; i < scoreList.size(); i++) {
                        product = new Product();
                        product.setName(scoreList.get(i).getString("name"));
                        product.setId(scoreList.get(i).getObjectId());
                        product.setCategorie(scoreList.get(i).getString("categorie"));
                        product.setDescription(scoreList.get(i).getString("description"));
                        product.setPrix(scoreList.get(i).getString("prix"));
                        product.setPromotion(scoreList.get(i).getBoolean("promotion"));
                        product.setQuantite(scoreList.get(i).getInt("quantite"));
                        final ParseFile fileObject = (ParseFile) scoreList.get(i).get("image");
                        product.setImage(fileObject.getUrl());
                        productList.add(product);
                    }
                    mAdapter = new CardAdapter(productList,getActivity().getSupportFragmentManager(),getActivity());
                    mRecyclerView.setAdapter(mAdapter);

                } else {
                    Log.d("ERROR", "Error: " + e.getMessage());
                }
            }
        });

        return view;

    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            //  mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void showHomeFragment(Fragment fragment) {

        Fragment home = fragment;
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction()

                .replace(R.id.container, home)
                .addToBackStack(home.getClass().getSimpleName())
                .commit();

    }
    public interface OnFragmentInteractionListener {
        public void onMenuSelection(String menu_item);
    }

}