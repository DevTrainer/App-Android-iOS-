//
//  DetailResViewController.h
//  Share_Car_iOS
//
//  Created by SWIMO on 05/12/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailResViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *liv;
@property (weak, nonatomic) IBOutlet UILabel *go;
@property (weak, nonatomic) IBOutlet UILabel *date;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UILabel *bag;
@property (weak, nonatomic) IBOutlet UILabel *pln;
@property (weak, nonatomic) IBOutlet UILabel *road;



@property  (strong,nonatomic) NSString* livin;
@property (strong, nonatomic) NSString *r1;
@property (strong, nonatomic) NSString *gto;
@property (strong, nonatomic) NSString *dte;
@property (strong, nonatomic) NSString *tme;
@property (strong, nonatomic) NSString *plnb;
@property (strong, nonatomic) NSString *baga;
@end
