//
//  AdsViewController.m
//  ShareCare
//
//  Created by share car on 24/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import "AdsViewController.h"
#import "RNFrostedSidebar.h"
#import "DetailsViewController.h"
#import "loginViewController.h"
#import "Ads.h"
#import "SingletonClass.h"
#import <QuartzCore/QuartzCore.h>

@interface AdsViewController ()

@end

@implementation AdsViewController
@synthesize adsTable;
PFObject *ads;
- (void)viewDidLoad {
    [super viewDidLoad];
    self.optionIndices = [NSMutableIndexSet indexSetWithIndex:1];
    [self retreiveDataFromAdsoffer];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

-(void) retreiveDataFromAdsoffer{
    PFQuery *query = [PFQuery queryWithClassName:@"ads"];
    [query includeKey:@"user"];
    [query whereKey:@"type" equalTo:@"OFFER"];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (! error){
            _listOfAds = [[NSArray alloc] initWithArray:objects];
        }
        [self.adsTable reloadData];
    }];
    
    
}
-(void) retreiveDataFromAdsreq{
    PFQuery *query = [PFQuery queryWithClassName:@"ads"];
    [query includeKey:@"user"];
    [query whereKey:@"type" equalTo:@"REQUEST"];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (! error){
            _listOfAds = [[NSArray alloc] initWithArray:objects];
        }
        [self.adsTable reloadData];
    }];
    
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell* cell= [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
       ads = [_listOfAds objectAtIndex:indexPath.row];
     PFUser *usr = ads[@"user"];
    // Configure the cell...
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    
    // Display recipe in the table cell
   // UIImageView *adsImageView = (UIImageView *)[cell viewWithTag:5];
   // adsImageView.image = [UIImage imageNamed:recipe.imageFile];
    
    UILabel *adsLeavingFrom = (UILabel *)[cell viewWithTag:6];
    adsLeavingFrom.text = [ads objectForKey:@"livingFrom"];
    
    UILabel *adsGoingTo = (UILabel *)[cell viewWithTag:1];
    adsGoingTo.text = [ads objectForKey:@"goingTo"];
    
    UILabel *adsRoadOn = (UILabel *)[cell viewWithTag:2];
    adsRoadOn.text = [ads objectForKey:@"roadOn"];
    
    UILabel *adsDate = (UILabel *)[cell viewWithTag:3];
    adsDate.text = [ads objectForKey:@"date"];
    
    UILabel *adsTime = (UILabel *)[cell viewWithTag:4];
    adsTime.text = [ads objectForKey:@"time"];
    PFFile *pictureFile = usr[@"Pimg"];
    
    [pictureFile getDataInBackgroundWithBlock:^(NSData *data, NSError *error) {
        UIImageView *im= (UIImageView *)[cell viewWithTag:110];
        im.layer.cornerRadius = im.frame.size.height / 2;
        im.clipsToBounds = YES;
        im.layer.borderWidth = 2.0f;
        im.layer.borderColor = [UIColor whiteColor].CGColor;
         im.image = [UIImage imageWithData:data];
           }];

    
    return cell;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section  {
    return _listOfAds.count;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    PFObject *AdsSelected = [_listOfAds objectAtIndex:indexPath.row];
    SingletonClass* sharedads = [SingletonClass sharedAds];
    [sharedads setAds:AdsSelected];
}

- (IBAction)SideBar:(id)sender {
    NSArray *images = @[
                        [UIImage imageNamed:@"profile"],
                        [UIImage imageNamed:@"globe"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"gear"],
                        [UIImage imageNamed:@"profile"],
                        [UIImage imageNamed:@"globe"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"star"],
                        ];
    NSArray *colors = @[
                        [UIColor colorWithRed:240/255.f green:159/255.f blue:254/255.f alpha:1],
                        [UIColor colorWithRed:255/255.f green:137/255.f blue:167/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        ];
    
    RNFrostedSidebar *callout = [[RNFrostedSidebar alloc] initWithImages:images selectedIndices:self.optionIndices borderColors:colors];
    callout.delegate = self;
    [callout show];

}
- (void)sidebar:(RNFrostedSidebar *)sidebar didTapItemAtIndex:(NSUInteger)index {
    NSLog(@"Tapped item at index %lu",(unsigned long)index);
    if (index == 0) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"listads"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 1) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"recherche"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 2) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"request"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 3) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"reservation"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 4) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"favorit"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 5) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"profil"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 6) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"about"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 7) {
        [sidebar dismissAnimated:YES completion:nil];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Log out of Share Car?"
                                                            message:nil
                                                           delegate:self
                                                  cancelButtonTitle:@"Log out"
                                                  otherButtonTitles:@"Cancel", nil];
        [alertView show];
        
    }

    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == alertView.cancelButtonIndex) {
        // Log out.
        [PFUser logOut];
        NSString * storyboardName = @"Main";
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"login"];
        
        [self presentViewController:vc animated:YES completion:nil];
        
    }
}

- (void)sidebar:(RNFrostedSidebar *)sidebar didEnable:(BOOL)itemEnabled itemAtIndex:(NSUInteger)index {
    if (itemEnabled) {
        [self.optionIndices addIndex:index];
    }
    else {
        [self.optionIndices removeIndex:index];
    }
}

- (IBAction)type:(id)sender {
    
    
    if(_typech.selectedSegmentIndex == 0)
    {
        [self retreiveDataFromAdsoffer];
    }
    else
    {
        [self retreiveDataFromAdsreq];
    }
}
@end