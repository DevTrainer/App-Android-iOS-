//
//  AboutViewController.m
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import "AboutViewController.h"
#import "RNFrostedSidebar.h"
#import <Parse/Parse.h>

@interface AboutViewController ()

@end

@implementation AboutViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.optionIndices = [NSMutableIndexSet indexSetWithIndex:1];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)SideBar:(id)sender {
    NSArray *images = @[
                        [UIImage imageNamed:@"gear"],
                        [UIImage imageNamed:@"globe"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"profile"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"star"],
                        ];
    NSArray *colors = @[
                        [UIColor colorWithRed:240/255.f green:159/255.f blue:254/255.f alpha:1],
                        [UIColor colorWithRed:255/255.f green:137/255.f blue:167/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        ];
    
    RNFrostedSidebar *callout = [[RNFrostedSidebar alloc] initWithImages:images selectedIndices:self.optionIndices borderColors:colors];
    callout.delegate = self;
    [callout show];
    
}
- (void)sidebar:(RNFrostedSidebar *)sidebar didTapItemAtIndex:(NSUInteger)index {
    NSLog(@"Tapped item at index %lu",(unsigned long)index);
    if (index == 0) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"listads"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 1) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"recherche"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 2) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"request"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 3) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"reservation"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 4) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"favorit"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 5) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"profil"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 6) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"about"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 7) {
        [sidebar dismissAnimated:YES completion:nil];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Log out of Share Car?"
                                                            message:nil
                                                           delegate:self
                                                  cancelButtonTitle:@"Log out"
                                                  otherButtonTitles:@"Cancel", nil];
        [alertView show];
        
    }
    
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == alertView.cancelButtonIndex) {
        // Log out.
        [PFUser logOut];
        NSString * storyboardName = @"Main";
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"login"];
        
        [self presentViewController:vc animated:YES completion:nil];
        
    }
}

- (void)sidebar:(RNFrostedSidebar *)sidebar didEnable:(BOOL)itemEnabled itemAtIndex:(NSUInteger)index {
    if (itemEnabled) {
        [self.optionIndices addIndex:index];
    }
    else {
        [self.optionIndices removeIndex:index];
    }
}
@end
