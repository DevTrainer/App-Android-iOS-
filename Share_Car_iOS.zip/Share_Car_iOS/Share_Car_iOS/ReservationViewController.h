//
//  ReservationViewController.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

@interface ReservationViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tabreservation;
@property (nonatomic, strong) NSMutableIndexSet *optionIndices;
- (IBAction)SideBar:(id)sender;
@property  (strong,nonatomic) NSArray* listOfreservation;
@property  (strong,nonatomic) NSString* place;
@property  (strong,nonatomic) NSString* bagage;
@property  (strong,nonatomic) PFFile *pictureFile;
@end
