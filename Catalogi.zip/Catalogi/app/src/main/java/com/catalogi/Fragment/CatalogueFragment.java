package com.catalogi.Fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.catalogi.R;

/**
 * Created by Wissem on 02/11/15.
 */
public class CatalogueFragment extends Fragment {

    public CatalogueFragment() {
    }
    private OnFragmentInteractionListener mListener;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.catalogue_fragment, container, false);
        ImageButton technologie = (ImageButton) view.findViewById(R.id.technologie);
        ImageButton clothes = (ImageButton) view.findViewById(R.id.clothes);
        ImageButton electromenager = (ImageButton) view.findViewById(R.id.electromenager);
        ImageButton toys = (ImageButton) view.findViewById(R.id.toys);



       electromenager.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               ProductListFragment fragment = new ProductListFragment();
               fragment.categorie = "Electromenager";
               showHomeFragment(new ProductListFragment());
           }
       });
        toys.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProductListFragment fragment = new ProductListFragment();
                fragment.categorie = "Toys";
                showHomeFragment(new ProductListFragment());
            }
        });
        technologie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProductListFragment fragment = new ProductListFragment();
                fragment.categorie = "Technology";
                showHomeFragment(new ProductListFragment());
            }
        });
        clothes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProductListFragment fragment = new ProductListFragment();
                fragment.categorie = "Clothes";
                showHomeFragment(new ProductListFragment());
            }
        });

        return view;

    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            //  mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        public void onMenuSelection(String menu_item);
    }
    public void showHomeFragment(Fragment fragment) {

        Fragment home = fragment;
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction()

                .replace(R.id.container, home)
                .addToBackStack(home.getClass().getSimpleName())
                .commit();

    }
}
