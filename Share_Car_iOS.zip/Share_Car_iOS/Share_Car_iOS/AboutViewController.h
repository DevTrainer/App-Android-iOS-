//
//  AboutViewController.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController
@property (nonatomic, strong) NSMutableIndexSet *optionIndices;
- (IBAction)SideBar:(id)sender;
@end
