//
//  AddAdsViewController.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface AddAdsViewController : UIViewController<UITextFieldDelegate>
- (IBAction)dismissView:(id)sender;
- (IBAction)ajoutAds:(id)sender;

@property (strong, nonatomic) IBOutlet UITextField *livfrom;
@property (strong, nonatomic) IBOutlet UITextField *roadOn;
@property (strong, nonatomic) IBOutlet UITextField *goingTo;
@property (strong, nonatomic) IBOutlet UITextField *date;
@property (strong, nonatomic) IBOutlet UITextField *time;
@property (strong, nonatomic) IBOutlet UISegmentedControl *bagege;
@property (strong, nonatomic) IBOutlet UITextField *price;
@property (strong, nonatomic) IBOutlet UITextField *placenbr;

@property (strong, nonatomic) IBOutlet NSString *LivingFrom;
@property (strong, nonatomic) IBOutlet NSString *rOn;
@property (strong, nonatomic) IBOutlet NSString *gTo;


@property (nonatomic, assign) BOOL activityViewVisible;
@property (nonatomic, strong) UIView *activityView;

@property (strong, nonatomic) CLGeocoder *geocoder;


@end
