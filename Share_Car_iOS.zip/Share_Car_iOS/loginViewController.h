//
//  loginViewController.h
//  ShareCare
//
//  Created by Wissem Rezgui on 20/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ParseFacebookUtils/PFFacebookUtils.h>
#import <FacebookSDK/FacebookSDK.h>

@interface loginViewController : UIViewController
- (IBAction)LogInFaceBookkPressed:(id)sender;
- (IBAction)Authentif:(id)sender;

@property (nonatomic, assign) BOOL activityViewVisible;
@property (nonatomic, strong) UIView *activityView;

@property (strong, nonatomic) IBOutlet UITextField *lbl_name;
@property (strong, nonatomic) IBOutlet UITextField *lbl_pass;

@end
