//
//  UIImage+Scaling.h
//  FBParse
//
//  Created by Toby Stephens on 02/06/2013.
//  Copyright (c) 2013 Toby Stephens. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <Parse/Parse.h>
#import <ParseFacebookUtils/PFFacebookUtils.h>
#import "Comms.h"

@interface UIImage (Scaling)

- (UIImage *) imageScaledToSize:(CGSize)size;
- (UIImage *) imageScaledToFitSize:(CGSize)size;

@end
