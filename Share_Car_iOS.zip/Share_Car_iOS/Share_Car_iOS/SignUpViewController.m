//
//  SignUpViewController.m
//  FBParse
//
//  Created by Wissem Rezgui on 09/11/2014.
//  Copyright (c) 2014 Toby Stephens. All rights reserved.
//

#import "SignUpViewController.h"
#import "loginViewController.h"
#import "UIImage+Scaling.h"
#import <Parse/Parse.h>
#import "PAWActivityView.h"
@interface SignUpViewController ()

@end

@implementation SignUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    PFUser *Currentuser = [PFUser currentUser];
    if (Currentuser != nil){
        _lbl_name.text = Currentuser.username;
        _lbl_mail.text = Currentuser.email;
        _lbl_adress.text = [Currentuser objectForKey:@"adress"];
        _tel.text = [Currentuser objectForKey:@"tel"];
        _lbl_password.text = Currentuser.password;
        PFFile *pictureFile = [Currentuser objectForKey:@"Pimg"];
        
        [pictureFile getDataInBackgroundWithBlock:^(NSData *data, NSError *error) {
            _img.image = [UIImage imageWithData:data];
            _lbl_password.hidden = true;
            
        }];
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

- (IBAction)uploadImage:(id)sender {
}

- (IBAction)Inscription:(id)sender {
    PFUser *user = [PFUser currentUser];
    if (user != nil ) {
        [self UpdateProfile:user];
    }
    [self SignUp];
}

-(void) UpdateProfile:(PFUser*)user {
    
    PAWActivityView *activityView = [[PAWActivityView alloc] initWithFrame:CGRectMake(0.f, 0.f, self.view.frame.size.width, self.view.frame.size.height)];
    UILabel *label = activityView.label;
    label.text = @"Updating your profile";
    label.font = [UIFont boldSystemFontOfSize:20.f];
    [activityView.activityIndicator startAnimating];
    [activityView layoutSubviews];
    
    
    [self.view addSubview:activityView];
    
    PFQuery *query = [PFUser query];
    user = (PFUser *)[query getObjectWithId:user.objectId];
    
    user.username = _lbl_name.text ;
    user.email = _lbl_mail.text ;
    user[@"adress"] =_lbl_adress.text ;
    user [@"tel"] = _tel.text ;
    
    
    NSData *imageData = UIImagePNGRepresentation(_img.image);
    PFFile *file = [PFFile fileWithData:imageData];
    
    
    //HUD creation here (see example for code)
    
    // Save PFFile
    [file saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        if (!error) {
            // Create a PFObject around a PFFile and associate it with the current user
            [user setObject:file forKey:@"Pimg"];
            
            [user saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                if (!error) {
                    NSLog(@"m3allem");
                    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
                }
                else{
                    // Log details of the failure
                    NSLog(@"Error: %@ %@", error, [error userInfo]);
                }
            }];
        }
        else{
            // Log details of the failure
            NSLog(@"Error: %@ %@", error, [error userInfo]);
        }
    }];
    
    
    [user save] ;
    if ([user save]) {
        NSLog(@"Registration success!");
        
        [activityView.activityIndicator stopAnimating];
        [activityView removeFromSuperview];
        
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    else {
        NSLog(@"There was an error in registration");
    }
    
    
}
- (void)SignUp {
    NSLog(@"registering....");
    PAWActivityView *activityView = [[PAWActivityView alloc] initWithFrame:CGRectMake(0.f, 0.f, self.view.frame.size.width, self.view.frame.size.height)];
    UILabel *label = activityView.label;
    label.text = @"Signing You Up";
    label.font = [UIFont boldSystemFontOfSize:20.f];
    [activityView.activityIndicator startAnimating];
    [activityView layoutSubviews];
    
    
    [self.view addSubview:activityView];
    
    PFUser *user = [PFUser user];
    user.username = _lbl_name.text;
    user.password = _lbl_password.text;
    user.email =_lbl_mail.text;
    
    // other fields can be set just like with PFObject
    user[@"adress"] =_lbl_adress.text;
    user[@"tel"] =_tel.text;
    
    // ...image view from previous code
    NSData *imageData = UIImagePNGRepresentation(_img.image);
    PFFile *file = [PFFile fileWithData:imageData];
    
    
    //HUD creation here (see example for code)
    
    // Save PFFile
    [file saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        if (!error) {
            // Create a PFObject around a PFFile and associate it with the current user
            [user setObject:file forKey:@"Pimg"];
            
            [user saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                if (!error) {
                    NSLog(@"m3allem");
                    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
                }
                else{
                    // Log details of the failure
                    NSLog(@"Error: %@ %@", error, [error userInfo]);
                }
            }];
        }
        else{
            // Log details of the failure
            NSLog(@"Error: %@ %@", error, [error userInfo]);
        }
    }];
    
    
    [user signUpInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        if (!error) {
            NSLog(@"Registration success!");
            
            [activityView.activityIndicator stopAnimating];
            [activityView removeFromSuperview];
            
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        else {
            NSLog(@"There was an error in registration");
        }
    }];
    
}
- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = info[UIImagePickerControllerEditedImage];
    [_img setImage:[image imageScaledToFitSize:_img.frame.size]];
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}
- (IBAction)chose_image:(id)sender {
    
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:NULL];
}
- (IBAction)retreive:(id)sender {
    [self retreveDataFromParse];
}

- (IBAction)dismiss_view:(id)sender {
    [[self presentingViewController] dismissViewControllerAnimated:YES completion:nil];

}
-(void)retreveDataFromParse{
    PFQuery *query = [PFQuery queryWithClassName:@"ads"];
    [query getObjectInBackgroundWithId:@"ZfCREIWaFu" block:^(PFObject *ads, NSError *error) {
        // Do something with the returned PFObject in the gameScore variable.
        NSLog(@"%@", ads);
    }];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}
@end
