package com.catalogi.Fragment;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.catalogi.R;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.DividerDrawerItem;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.SecondaryDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;
import com.parse.GetDataCallback;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseUser;


public class MainActivity extends AppCompatActivity {

    AlertDialog.Builder alertDialogBuilder ;
    AccountHeader headerResult;
    Bitmap bmp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final PrimaryDrawerItem item1 = new PrimaryDrawerItem().withName("Profil").withIcon(getResources().getDrawable(R.drawable.man42)).withIdentifier(1);
        final SecondaryDrawerItem item2 = new SecondaryDrawerItem().withName("Catalog").withIcon(getResources().getDrawable(R.drawable.catalog2)).withIdentifier(2);
        SecondaryDrawerItem item3 = new SecondaryDrawerItem().withName("Promotion").withIcon(getResources().getDrawable(R.drawable.listprod)).withIdentifier(3);
        SecondaryDrawerItem item4 = new SecondaryDrawerItem().withName("Basket").withIcon(getResources().getDrawable(R.drawable.shopping145)).withIdentifier(4);
        SecondaryDrawerItem item5 = new SecondaryDrawerItem().withName("Settings").withIcon(getResources().getDrawable(R.drawable.settings48)).withIdentifier(5);
        SecondaryDrawerItem item6 = new SecondaryDrawerItem().withName("Logout").withIcon(getResources().getDrawable(R.drawable.logout13)).withIdentifier(6);
        SecondaryDrawerItem item7 = new SecondaryDrawerItem().withName("3D").withIcon(getResources().getDrawable(R.drawable.augmented)).withIdentifier(7);

        alertDialogBuilder = new AlertDialog.Builder(
                this);

        ParseUser user = ParseUser.getCurrentUser();
        if(user != null) {
            ParseFile applicantResume = (ParseFile)user.get("image");
            applicantResume.getDataInBackground(new GetDataCallback() {
                public void done(byte[] data, ParseException e) {
                    if (e == null) {
                         bmp = BitmapFactory
                                .decodeByteArray(
                                        data, 0,
                                        data.length);
                    } else {
                        // something went wrong
                    }
                }
            });
            headerResult = new AccountHeaderBuilder()
                    .withActivity(this)
                    .withHeaderBackground(R.drawable.header)
                    .build();
        }else{
            headerResult = new AccountHeaderBuilder()
                    .withActivity(this)
                    .withHeaderBackground(R.drawable.header)
                    .build();
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Drawer result = new DrawerBuilder()
                .withActivity(this)
                .withToolbar(toolbar)
                .withAccountHeader(headerResult)
                .withTranslucentStatusBar(true)
                .withActionBarDrawerToggle(true)
                .addDrawerItems(
                        item1,
                        new DividerDrawerItem(),
                        item2,
                        item3,
                        item4,
                        item5,
                        item7,
                        new DividerDrawerItem(),
                        item6

                )
                .withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
                    @Override
                    public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                        switch (drawerItem.getIdentifier()) {
                            case 1:
                                ParseUser currentUser = ParseUser.getCurrentUser();
                                if (currentUser != null) {
                                    showHomeFragment(new ComptFragment());
                                } else {
                                    showHomeFragment(new Authentification());
                                }
                                break;
                            case 2:
                                showHomeFragment(new CatalogueFragment());
                                break;
                            case 3:
                                showHomeFragment(new ProductListFragmentPromos());
                                break;
                            case 4:
                                ParseUser currentUser2 = ParseUser.getCurrentUser();
                                if (currentUser2 != null) {
                                    showHomeFragment(new PanierFragment());
                                } else {
                                    showAlert("Vous devez Connecté pour avoir votre Panier","Pas de compt disponible");
                                }
                                break;
                            case 5:
                                showHomeFragment(new LimiteurFragment());
                                break;
                            case 6:
                                ParseUser.logOut();
                                showHomeFragment(new Authentification());
                                break;
                            case 7:
                                launchApp("com.esprit.catalog");
                                break;
                        }
                return false;
                    }
                })
                .build();
        showHomeFragment(new CatalogueFragment());
    }


    public void showHomeFragment(Fragment fragment) {

        Fragment home = fragment;
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()

                .replace(R.id.container, home)
                .addToBackStack(home.getClass().getSimpleName())
                .commit();

    }
    public void showAlert(String message,String Titre){
        alertDialogBuilder.setTitle(Titre);
        alertDialogBuilder
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        showHomeFragment(new Authentification());
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
    protected void launchApp(String packageName) {
        Intent mIntent = getPackageManager().getLaunchIntentForPackage(
                packageName);
        if (mIntent != null) {
            try {
                startActivity(mIntent);
            } catch (ActivityNotFoundException err) {
                Toast t = Toast.makeText(MainActivity.this,
                        "No app found", Toast.LENGTH_SHORT);
                t.show();
            }
        }
    }
}
