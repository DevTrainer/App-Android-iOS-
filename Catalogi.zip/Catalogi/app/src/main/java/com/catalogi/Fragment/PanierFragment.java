package com.catalogi.Fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.catalogi.Model.Reservation;
import com.catalogi.R;
import com.parse.DeleteCallback;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Wissem on 02/11/15.
 */
public class PanierFragment extends Fragment  {


    private List<Reservation> panierlist = null;
    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter mAdapter;
    TextView textView;
    Button button;
    int budget;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_panier, container, false);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view_panier);
        mRecyclerView.setHasFixedSize(true);
        textView= (TextView)view.findViewById(R.id.textView3);
        button= (Button)view.findViewById(R.id.button);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        new RemoteDataTask().execute();
        loadSavedPreferences();
        textView.setText("Total: " + budget + " TND");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAlert(v);
            }
        });
        return view;

    }
    private void openAlert(View view) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

        alertDialogBuilder.setTitle("Réservation");

        alertDialogBuilder.setMessage("Vous voulez vraiment réserver tous ces produits?");

        // set positive button: Yes message

        alertDialogBuilder.setPositiveButton("Oui", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                ParseQuery query = new ParseQuery("Reservation");
                ParseUser currentUser = ParseUser.getCurrentUser();
                query.whereEqualTo("user", currentUser);
                query.findInBackground(new FindCallback<ParseObject>() {
                    @Override
                    public void done(List<ParseObject> list, ParseException e) {
                        if (e == null) {
                            ParseObject.deleteAllInBackground(list, new DeleteCallback() {
                                @Override
                                public void done(ParseException e) {
                                    savePreferences("mybudget", 0);
                                    textView.setText("Total: " + 0 + " TND");
                                    mRecyclerView.setAdapter(null);

                                }
                            });
                        }
                    }
                });

            }

        });

        // set negative button: No message

        alertDialogBuilder.setNegativeButton("Non", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                // cancel the alert box and put a Toast to the user

                dialog.cancel();


            }

        });

        AlertDialog alertDialog = alertDialogBuilder.create();

        // show alert

        alertDialog.show();

    }

    private class RemoteDataTask extends AsyncTask<Void, Void, List<Reservation>> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected List<Reservation> doInBackground(Void... params) {
            // Create the array
            panierlist = new ArrayList<Reservation>();
            final ParseUser user = ParseUser.getCurrentUser();
            final ParseQuery<ParseObject> query = ParseQuery.getQuery("Reservation");
            query.whereEqualTo("user", user);
            query.include("produit");
            query.findInBackground(new FindCallback<ParseObject>() {
                public void done(List<ParseObject> produitList, ParseException e) {
                    if (e == null) {
                        for (int i = 0; i < produitList.size(); i++) {
                            ParseObject produit = produitList.get(i).getParseObject("produit");
                            Reservation reservation = new Reservation();
                            reservation.setReservation(produit);
                            panierlist.add(reservation);
                        }
                        mAdapter = new PanierAdapter(panierlist,getActivity().getSupportFragmentManager(),getActivity());
                        // Binds the Adapter to the ListView
                        mRecyclerView.setAdapter(mAdapter);

                    } else {
                        Log.d("ERROR", "Error: " + e.getMessage());
                    }
                }
            });

            return panierlist;
        }

        @Override
        protected void onPostExecute(List<Reservation> result) {
            // Locate the listview in listview_main.xml
            // Pass the results into ListViewAdapter.java


        }
    }
    private void loadSavedPreferences() {
        SharedPreferences sharedPreferences = PreferenceManager

                .getDefaultSharedPreferences(getActivity().getApplicationContext());


        budget = sharedPreferences.getInt("mybudget", 0);

    }

    private void savePreferences(String key, int value) {

        SharedPreferences sharedPreferences = PreferenceManager

                .getDefaultSharedPreferences(getActivity().getApplicationContext());

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt(key, value);

        editor.commit();

    }
}