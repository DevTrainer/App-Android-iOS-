//
//  ReservationViewController.m
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import "ReservationViewController.h"
#import "RNFrostedSidebar.h"
#import "DetailResViewController.h"

@interface ReservationViewController ()

@end

@implementation ReservationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.optionIndices = [NSMutableIndexSet indexSetWithIndex:3];
    [self retreiveDataFromreservation];
}
-(void) retreiveDataFromreservation{
    PFQuery *query = [PFQuery queryWithClassName:@"reservation"];
    [query whereKey:@"user" equalTo:[PFUser currentUser]];
    [query includeKey:@"ads"];
    [query includeKey:@"user"];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (! error){
            _listOfreservation = [[NSArray alloc] initWithArray:objects];
        }
        [self.tabreservation reloadData];
    }];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section  {
    return _listOfreservation.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell* cell= [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    PFObject *res = [_listOfreservation objectAtIndex:indexPath.row];
    PFObject *ads = res [@"ads"];
    
    // Configure the cell...
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    UILabel *adsLeavingFrom = (UILabel *)[cell viewWithTag:6];
    adsLeavingFrom.text = [ads objectForKey:@"livingFrom"];
    
    UILabel *adsGoingTo = (UILabel *)[cell viewWithTag:1];
    adsGoingTo.text = [ads objectForKey:@"goingTo"];
    
    UILabel *adsRoadOn = (UILabel *)[cell viewWithTag:2];
    adsRoadOn.text = [ads objectForKey:@"roadOn"];
    
    UILabel *adsDate = (UILabel *)[cell viewWithTag:3];
    adsDate.text = [ads objectForKey:@"date"];
    
    UILabel *adsTime = (UILabel *)[cell viewWithTag:4];
    adsTime.text = [ads objectForKey:@"time"];
    
    _place=[res objectForKey:@"placeNbr"];
    _bagage=[res objectForKey:@"bagage"];
    
    
    ////////////////////////
    PFUser *user = ads [@"user"];
    PFQuery *query = [PFQuery queryWithClassName:@"_User"];
    [query getObjectInBackgroundWithId:user.objectId block:^(PFObject *usr, NSError *error) {
        // Do something with the returned PFObject in the gameScore variable.
        _pictureFile = usr[@"Pimg"];
        [_pictureFile getDataInBackgroundWithBlock:^(NSData *data, NSError *error) {
            UIImageView *im= (UIImageView *)[cell viewWithTag:25];
            im.layer.cornerRadius = im.frame.size.height / 2;
            im.clipsToBounds = YES;
            im.layer.borderWidth = 2.0f;
            im.layer.borderColor = [UIColor whiteColor].CGColor;
            im.image = [UIImage imageWithData:data];
    }];
    
    }];
    
    ///////////////////////////
    
    return cell;
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    DetailResViewController* DVC = segue.destinationViewController;
    NSIndexPath *indexpath = [_tabreservation indexPathForSelectedRow];
    PFObject *res = [_listOfreservation objectAtIndex:indexpath.row];
    PFObject *ads = res [@"ads"];

    DVC.livin = [ads objectForKey:@"livingFrom"];
    DVC.gto = [ads objectForKey:@"goingTo"];
    DVC.r1 = [ads objectForKey:@"roadOn"];
    DVC.dte= [ads objectForKey:@"date"];
    DVC.tme = [ads objectForKey:@"time"];
    DVC.plnb= [res objectForKey:@"placeNbr"];
    DVC.baga = [res objectForKey:@"bagage"];
    
    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)SideBar:(id)sender {
    NSArray *images = @[
                        [UIImage imageNamed:@"gear"],
                        [UIImage imageNamed:@"globe"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"profile"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"star"],
                        ];
    NSArray *colors = @[
                        [UIColor colorWithRed:240/255.f green:159/255.f blue:254/255.f alpha:1],
                        [UIColor colorWithRed:255/255.f green:137/255.f blue:167/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        ];
    
    RNFrostedSidebar *callout = [[RNFrostedSidebar alloc] initWithImages:images selectedIndices:self.optionIndices borderColors:colors];
    callout.delegate = self;
    [callout show];
    
}
- (void)sidebar:(RNFrostedSidebar *)sidebar didTapItemAtIndex:(NSUInteger)index {
    NSLog(@"Tapped item at index %lu",(unsigned long)index);
    if (index == 0) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"listads"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 1) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"recherche"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 2) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"request"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 3) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"reservation"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 4) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"favorit"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 5) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"profil"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 6) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"about"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 7) {
        [sidebar dismissAnimated:YES completion:nil];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Log out of Share Car?"
                                                            message:nil
                                                           delegate:self
                                                  cancelButtonTitle:@"Log out"
                                                  otherButtonTitles:@"Cancel", nil];
        [alertView show];
        
    }
    
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == alertView.cancelButtonIndex) {
        // Log out.
        [PFUser logOut];
        NSString * storyboardName = @"Main";
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"login"];
        
        [self presentViewController:vc animated:YES completion:nil];
        
    }
}

- (void)sidebar:(RNFrostedSidebar *)sidebar didEnable:(BOOL)itemEnabled itemAtIndex:(NSUInteger)index {
    if (itemEnabled) {
        [self.optionIndices addIndex:index];
    }
    else {
        [self.optionIndices removeIndex:index];
    }
}

@end
