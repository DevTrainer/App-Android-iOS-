package com.catalogi.Model;

/**
 * Created by Wissem on 08/11/15.
 */
public class Catalogue {
}
