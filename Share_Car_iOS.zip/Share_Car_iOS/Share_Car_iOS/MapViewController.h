//
//  MapViewController.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 02/12/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import<CoreLocation/CoreLocation.h>
#import<Foundation/Foundation.h>
#import "SingletonClass.h"
#import <Parse/Parse.h>

@interface MapViewController : UIViewController
@property (strong, nonatomic) IBOutlet MKMapView *mapView;
@property (nonatomic) CLLocationCoordinate2D point;
@end
