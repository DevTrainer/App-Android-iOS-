//
//  DetailResViewController.m
//  Share_Car_iOS
//
//  Created by SWIMO on 05/12/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import "DetailResViewController.h"

@interface DetailResViewController ()

@end

@implementation DetailResViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _liv.text = _livin;
    _go.text = _gto;
    _road.text = _r1;
    _date.text = _dte;
    _time.text = _tme;
    _bag.text = _baga;
    _pln.text = (@"place left,%@",_plnb);
    NSLog(@"%@",_plnb);
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
