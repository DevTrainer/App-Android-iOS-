package com.catalogi.Fragment;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.catalogi.R;
import com.parse.GetDataCallback;
import com.parse.ParseFile;
import com.parse.ParseUser;
import com.parse.ParseException;

/**
 * Created by Wissem on 09/11/15.
 */
public class ComptFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        TextView name = (TextView) view.findViewById(R.id.username_profile);
        TextView email = (TextView) view.findViewById(R.id.email_profile);
        TextView phoneNumber = (TextView) view.findViewById(R.id.phone_number_profile);
        TextView adresse = (TextView) view.findViewById(R.id.adresse_profile);
        final ImageView profile_image = (ImageView) view.findViewById(R.id.img_thumbnail_profile);

        ParseUser currentUser = ParseUser.getCurrentUser();
        if (currentUser != null) {

            name.setText(currentUser.getUsername());
            email.setText(currentUser.getEmail());
            phoneNumber.setText(currentUser.getString("phone"));
            adresse.setText(currentUser.getString("adresse"));
            ParseFile fileObject = (ParseFile) currentUser.get("image");
            fileObject.getDataInBackground(new GetDataCallback() {

                public void done(byte[] data,
                                 ParseException e) {
                    if (e == null) {
                        Log.d("test",
                                "We've got data in data.");
                        Bitmap bmp = BitmapFactory
                                .decodeByteArray(
                                        data, 0,
                                        data.length);
                        profile_image.setImageBitmap(bmp);
                    } else {
                        Log.d("test",
                                "There was a problem downloading the data.");
                    }
                }
            });

        } else {
            showHomeFragment(new Authentification());
        }

        return view;

    }
    public void showHomeFragment(Fragment fragment) {
        Fragment home = fragment;
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container, home)
                .addToBackStack(getClass().getSimpleName())
                .commit();
    }
}
