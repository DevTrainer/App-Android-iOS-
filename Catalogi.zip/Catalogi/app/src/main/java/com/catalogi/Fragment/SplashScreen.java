package com.catalogi.Fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.catalogi.Model.Catalogue;
import com.catalogi.R;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.parse.Parse;
import com.pnikosis.materialishprogress.ProgressWheel;

import java.util.ArrayList;
import java.util.List;


public class SplashScreen extends Activity {
    private static final String TAG ="" ;
    TextView logo;
    Animation anim1;
    Animation anim2;
    Animation anim3;
    ProgressWheel progress;
    static final String ACTION_SCAN = "com.google.zxing.client.android.SCAN";

    int id;
    ArrayList<com.catalogi.Model.Catalogue> listBanque = new ArrayList<Catalogue>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.splash_screen_layout);

        Parse.enableLocalDatastore(this);
        Parse.initialize(this, "QfVdmSzfL4QAG23dxXZGSvyDuWEIf71I1nlFxbdG", "KPZt0mHMPYJut42CWAvqbW5s9f6KYJt0jOalF1lj");

        logo = (TextView)findViewById(R.id.name_app);
        progress =(ProgressWheel)findViewById(R.id.progress_wheel);
        // start = (ImageView) findViewById(R.id.imageView1);

        anim1 = AnimationUtils.loadAnimation(this, R.anim.animation1);
        anim1.reset();
        anim2 = AnimationUtils.loadAnimation(this, R.anim.animation2);
        anim2.reset();
        anim3 = AnimationUtils.loadAnimation(this, R.anim.animation3);
        anim3.reset();


        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                logo.setVisibility(View.VISIBLE);
                findViewById(R.id.name_app).setVisibility(View.VISIBLE);
                logo.startAnimation(anim1);

                YoYo.with(Techniques.FadeIn).duration(1500).playOn(findViewById(R.id.name_app));
                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {

                    }

                }, 1500);
            }
        }, 1000);





        new RemoteDataTask().execute();


    }

    public void scanQR() {
        try {
            Intent intent = new Intent(ACTION_SCAN);
            intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
            startActivityForResult(intent, 0);
        } catch (ActivityNotFoundException anfe) {
        }
    }
    private AlertDialog showDialog(final Activity act, CharSequence title, CharSequence message, CharSequence buttonYes) {
        AlertDialog.Builder downloadDialog = new AlertDialog.Builder(act);
        downloadDialog.setTitle(title);
        downloadDialog.setMessage(message);
        downloadDialog.setPositiveButton(buttonYes, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                scanQR();
            }
        });
        return downloadDialog.show();
    }
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                String contents = intent.getStringExtra("SCAN_RESULT");
                if(contents.equals("http://q-r.to/carwashpanoramidC"))
                {
                    Intent i = new Intent(SplashScreen.this,MainActivity.class);
                    startActivity(i
                    );
                }else{
                    showDialog(this, "No Valid QRCode", "Please Scan a Valid QR code to get Catalogue", "OK").show();
                }
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private class RemoteDataTask extends AsyncTask<Void, Void, List<Catalogue>> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progress.setVisibility(View.VISIBLE);
            progress.spin();

        }

        @Override
        protected List<Catalogue> doInBackground(Void... params) {

            return listBanque;
        }

        @Override
        protected void onPostExecute(final List<Catalogue> result) {
            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    progress.setVisibility(View.INVISIBLE);
                    scanQR();
                }

            },2500);



        }


    }
}
