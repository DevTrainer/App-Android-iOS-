//
//  ProfilViewController.m
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import "ProfilViewController.h"
#import "RNFrostedSidebar.h"
#import <ParseUI/ParseUI.h>
#import <Parse/Parse.h>

@interface ProfilViewController ()

@end

@implementation ProfilViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.optionIndices = [NSMutableIndexSet indexSetWithIndex:1];
    [self GetProfileInformation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)SideBar:(id)sender {
    NSArray *images = @[
                        [UIImage imageNamed:@"gear"],
                        [UIImage imageNamed:@"globe"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"profile"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"star"],
                        [UIImage imageNamed:@"star"],
                        ];
    NSArray *colors = @[
                        [UIColor colorWithRed:240/255.f green:159/255.f blue:254/255.f alpha:1],
                        [UIColor colorWithRed:255/255.f green:137/255.f blue:167/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        [UIColor colorWithRed:119/255.f green:152/255.f blue:255/255.f alpha:1],
                        ];
    
    RNFrostedSidebar *callout = [[RNFrostedSidebar alloc] initWithImages:images selectedIndices:self.optionIndices borderColors:colors];
    callout.delegate = self;
    [callout show];
    
}
- (void)sidebar:(RNFrostedSidebar *)sidebar didTapItemAtIndex:(NSUInteger)index {
    NSLog(@"Tapped item at index %lu",(unsigned long)index);
    if (index == 0) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"listads"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 1) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"recherche"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 2) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"request"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 3) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"reservation"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 4) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"favorit"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 5) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"profil"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 6) {
        [sidebar dismissAnimated:YES completion:nil];
        UINavigationController *settingsNC = [self.storyboard instantiateViewControllerWithIdentifier:@"about"];
        
        [settingsNC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        // Present the view controller;
        [self presentViewController:settingsNC animated:YES completion:NULL];
    }
    if (index == 7) {
        [sidebar dismissAnimated:YES completion:nil];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Log out of Share Car?"
                                                            message:nil
                                                           delegate:self
                                                  cancelButtonTitle:@"Log out"
                                                  otherButtonTitles:@"Cancel", nil];
        [alertView show];
        
    }
    
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == alertView.cancelButtonIndex) {
        // Log out.
        [PFUser logOut];
        NSString * storyboardName = @"Main";
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"login"];
        
        [self presentViewController:vc animated:YES completion:nil];
        
    }
}


- (void)sidebar:(RNFrostedSidebar *)sidebar didEnable:(BOOL)itemEnabled itemAtIndex:(NSUInteger)index {
    if (itemEnabled) {
        [self.optionIndices addIndex:index];
    }
    else {
        [self.optionIndices removeIndex:index];
    }
}
-(void) GetProfileInformation {
    PFUser *user = [PFUser currentUser];
    _user_name.text = user.username;
    _email.text = user.email;
    _adresse.text = [user objectForKey:@"adress"];
    _telephone.text = [user objectForKey:@"tel"];
    PFFile *pictureFile = [user objectForKey:@"Pimg"];
    
    [pictureFile getDataInBackgroundWithBlock:^(NSData *data, NSError *error) {
        _profile_img.image = [UIImage imageWithData:data];
        
    }];
    
}

@end
