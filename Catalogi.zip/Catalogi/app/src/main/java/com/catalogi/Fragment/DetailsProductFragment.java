package com.catalogi.Fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.catalogi.Model.Product;
import com.catalogi.R;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SaveCallback;

/**
 * Created by Wissem on 08/11/15.
 */
public class DetailsProductFragment extends Fragment {

    public static Product p ;
    public TextView name;
    public TextView description;
    public TextView categorie;
    public TextView price;
    public ImageView image;
    public ImageLoader imageLoader;
    public Button reserver;
    AlertDialog.Builder alertDialogBuilder ;
    ParseObject reservation;
    ParseUser currentUser;
    boolean limiteurStatut;
    int budgetMax;
    int budget;

    private OnFragmentInteractionListener mListener;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_product_details, container, false);
        name = (TextView) view.findViewById(R.id.name);
        description = (TextView) view.findViewById(R.id.description);
        categorie = (TextView) view.findViewById(R.id.categorie);

        price = (TextView) view.findViewById(R.id.price);
        image = (ImageView) view.findViewById(R.id.img_thumbnail_details);
        reserver = (Button) view.findViewById(R.id.reserver);
        imageLoader = new ImageLoader(getActivity());
        alertDialogBuilder = new AlertDialog.Builder(getActivity());
        reservation = new ParseObject("Reservation");
        currentUser = ParseUser.getCurrentUser();
        loadSavedPreferences();

        name.setText(p.getName());
        description.setText("Product Description : "+p.getDescription());
        categorie.setText("Category : "+p.getCategorie());
        price.setText(p.getPrix() +" TND");
        imageLoader.DisplayImage(p.getImage(),
                image);

        reserver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (limiteurStatut)
                {

                    if (budget+Integer.valueOf(p.getPrix())<=budgetMax)
                    {

                        savePreferences("mybudget", budget + Integer.valueOf(p.getPrix()));


                        if (currentUser != null) {
                            reservation.put("user", currentUser);
                            reservation.put("produit", ParseObject.createWithoutData("Produit", p.getId()));
                            reservation.put("qu", 3);
                            reservation.saveInBackground(new SaveCallback() {
                                @Override
                                public void done(ParseException e) {
                                    Toast.makeText(getActivity(),
                                            "L'article a été ajouté à votre panier", Toast.LENGTH_SHORT).show();                        }
                            });
                        } else {
                            showAlert("Vous Devez connecté pour ajouter des produit au panier", "Alert");
                        }}
                    else{
                        alertDialogBuilder.setTitle("Alert");
                        alertDialogBuilder
                                .setMessage("Vous avez dépassé la limite de votre budget!")
                                .setCancelable(false)
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                    }
                                });
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();


                    }

                }
                else
                {
                    savePreferences("mybudget", budget+Integer.valueOf(p.getPrix()));

                    if (currentUser != null) {
                        reservation.put("user", currentUser);
                        reservation.put("produit", ParseObject.createWithoutData("Produit",p.getId()));
                        reservation.put("qu", 3);
                        reservation.saveInBackground(new SaveCallback() {
                            @Override
                            public void done(ParseException e) {
                                Toast.makeText(getActivity(),
                                        "L'article a été ajouté à votre panier", Toast.LENGTH_SHORT).show();                        }
                        });
                    } else {
                        showAlert("Vous Devez connecté pour ajouter des produit au panier", "Alert");
                    }
                }

            }
        });


        return view;

    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            //  mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        public void onMenuSelection(String menu_item);
    }
    public void showAlert(String message,String Titre){
        alertDialogBuilder.setTitle(Titre);
        alertDialogBuilder
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        showHomeFragment(new Authentification());
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
    public void showHomeFragment(Fragment fragment) {

        Fragment home = fragment;
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction()

                .replace(R.id.container, home)
                .addToBackStack(home.getClass().getSimpleName())
                .commit();

    }

    private void loadSavedPreferences() {
        SharedPreferences sharedPreferences = PreferenceManager

                .getDefaultSharedPreferences(getActivity().getApplicationContext());

        limiteurStatut = sharedPreferences.getBoolean("CheckBox_Value", false);
        budgetMax = sharedPreferences.getInt("budget", 0);
        budget = sharedPreferences.getInt("mybudget", 0);

    }


    private void savePreferences(String key, int value) {

        SharedPreferences sharedPreferences = PreferenceManager

                .getDefaultSharedPreferences(getActivity().getApplicationContext());

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt(key, value);

        editor.commit();

    }
}