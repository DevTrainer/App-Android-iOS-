//
//  DetailsMyAdsViewController.m
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 01/12/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import "DetailsMyAdsViewController.h"

@interface DetailsMyAdsViewController ()

@end

@implementation DetailsMyAdsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _livingfromm.text = _livingfrom;
    _gotoo.text = _goingto;
    _roadon.text = _roadOn;
    _Datee.text = _date;
    _tim.text = _time;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
