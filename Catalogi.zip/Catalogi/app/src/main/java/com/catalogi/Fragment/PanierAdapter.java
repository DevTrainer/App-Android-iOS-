package com.catalogi.Fragment;

import android.content.Context;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.catalogi.Model.Reservation;
import com.catalogi.R;
import com.parse.ParseFile;

import java.util.List;

public class PanierAdapter extends RecyclerView.Adapter<PanierAdapter.ViewHolder> {

    List<Reservation> mItems;
    FragmentManager fragmentManager;
    ImageLoader imageLoader;
    Context context;
    public PanierAdapter(List<Reservation> products,FragmentManager fragmentManager,Context context) {
        super();
        mItems = products;
        this.fragmentManager = fragmentManager;
        this.context=context;
        imageLoader = new ImageLoader(context);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.listview_item, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        final Reservation product = mItems.get(i);
        viewHolder.panier_price.setText(" : "+product.getReservation().getString("prix")+ " TND");
        viewHolder.panier_quantite.setText(" : "+product.getReservation().getString("name"));
        ParseFile file = (ParseFile) product.getReservation().get("image");
        imageLoader.DisplayImage(file.getUrl(),
                viewHolder.image);

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{


        public TextView panier_price;
        public TextView panier_quantite;
        public ImageView image;

        public ViewHolder(View itemView) {
            super(itemView);

            panier_price = (TextView)itemView.findViewById(R.id.panier_prix);
            panier_quantite= (TextView)itemView.findViewById(R.id.panier_quantite);
            image = (ImageView) itemView.findViewById(R.id.flag);
        }
    }

}

