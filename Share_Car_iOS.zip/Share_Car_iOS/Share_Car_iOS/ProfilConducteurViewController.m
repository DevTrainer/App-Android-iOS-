//
//  ProfilConducteurViewController.m
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 02/12/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import "ProfilConducteurViewController.h"
#import "SingletonClass.h"

@interface ProfilConducteurViewController ()
{
    PFUser *usr;
}
@end

@implementation ProfilConducteurViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    SingletonClass* sharedSingleton = [SingletonClass sharedAds];
    PFObject *AdsSelected = [sharedSingleton ads];
     usr = AdsSelected[@"user"];
    _userName.text = usr.username;
    _mail.text = usr.email;
    _telphone.text = usr[@"tel"];
    PFFile *pictureFile = usr[@"Pimg"];
    
    [pictureFile getDataInBackgroundWithBlock:^(NSData *data, NSError *error) {
        _profile_img.image = [UIImage imageWithData:data];
        _profile_img.layer.cornerRadius = _profile_img.frame.size.height / 2;
        _profile_img.clipsToBounds = YES;
        _profile_img.layer.borderWidth = 2.0f;
        _profile_img.layer.borderColor = [UIColor whiteColor].CGColor;
        
    }];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)Add_To_Favoris:(id)sender {
    PFObject *favoris = [PFObject objectWithClassName:@"favoris"];
    PFUser *user = [PFUser currentUser];
    favoris[@"iduser"] =user;
    favoris[@"idcond"] = usr;
    [favoris saveInBackground];
    [favoris saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        if (!error) {
            NSLog(@"jawou fesfes tzed lel favoris");
        }
        else{
            // Log details of the failure
            NSLog(@"Error: %@ %@", error, [error userInfo]);
        }
    }];
    
    
}

- (IBAction)sendSMS:(id)sender {
     [self sendSMS:@"Body of SMS..." recipientList:[NSArray arrayWithObjects:@"+1-111-222-3333", @"111-333-4444", nil]];
}

- (IBAction)sendMAIL:(id)sender {
}

- (IBAction)RateConducteur:(id)sender {
}

- (void)sendSMS:(NSString *)bodyOfMessage recipientList:(NSArray *)recipients
{
    MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
    if([MFMessageComposeViewController canSendText])
    {
        controller.body = bodyOfMessage;
        controller.recipients = recipients;
        controller.messageComposeDelegate = self;
         [self presentViewController:controller animated:YES completion:nil];
    }
}

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [[self presentingViewController] dismissViewControllerAnimated:YES completion:nil];
    
    if (result == MessageComposeResultCancelled)
        NSLog(@"Message cancelled");
        else if (result == MessageComposeResultSent)
            NSLog(@"Message sent");
            else 
                NSLog(@"Message failed");
                }
@end
