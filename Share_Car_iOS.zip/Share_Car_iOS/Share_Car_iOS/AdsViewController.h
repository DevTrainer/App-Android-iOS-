//
//  AdsViewController.h
//  ShareCare
//
//  Created by Wissem Rezgui on 24/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>


@interface AdsViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *adsTable;
@property  (strong,nonatomic) NSArray* listOfAds;
@property  (strong,nonatomic) NSArray* listOfUser;

- (IBAction)type:(id)sender;
@property (weak, nonatomic) IBOutlet UISegmentedControl *typech;


@property  (strong,nonatomic) NSString* objectId;
@property (nonatomic, strong) NSMutableIndexSet *optionIndices;

- (IBAction)SideBar:(id)sender;
@end
