//
//  DetailsViewController.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Ads.h"
#import <Parse/Parse.h>

@interface DetailsViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *livingFrom;
@property (strong, nonatomic) IBOutlet UILabel *roadOn;
@property (strong, nonatomic) IBOutlet UILabel *goingTo;
@property (strong, nonatomic) IBOutlet UILabel *date;
@property (strong, nonatomic) IBOutlet UILabel *time;
@property (nonatomic, strong) UIView *activityView;

- (IBAction)ReserverAds:(id)sender;

@end
