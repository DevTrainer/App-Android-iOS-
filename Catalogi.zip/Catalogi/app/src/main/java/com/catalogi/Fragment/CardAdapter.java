package com.catalogi.Fragment;

import android.content.Context;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.catalogi.Model.Product;
import com.catalogi.R;

import java.util.List;


/**
 * Created by Edwin on 18/01/2015.
 */

public class CardAdapter extends RecyclerView.Adapter<CardAdapter.ViewHolder> {

    List<Product> mItems;
    FragmentManager fragmentManager;
    ImageLoader imageLoader;
    Context context;
    public CardAdapter(List<Product> products,FragmentManager fragmentManager,Context context) {
        super();
        mItems = products;
        this.fragmentManager = fragmentManager;
        this.context=context;
        imageLoader = new ImageLoader(context);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.recycler_view_card_item, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        final Product product = mItems.get(i);
        viewHolder.product_name.setText(product.getName());
        viewHolder.product_price.setText(product.getPrix()+" TND");
        imageLoader.DisplayImage(product.getImage(),
                viewHolder.image);

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DetailsProductFragment home = new DetailsProductFragment();
                home.p=product;
                // update the main content by replacing fragments
                fragmentManager.beginTransaction()
                        .replace(R.id.container, home)
                        .addToBackStack(home.getClass().getSimpleName())
                        .commit();
            }
        });

    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{


        public TextView product_name;
        public TextView product_price;
        public ImageView image;

        public ViewHolder(View itemView) {
            super(itemView);

            product_name = (TextView)itemView.findViewById(R.id.product_name);
            product_price= (TextView)itemView.findViewById(R.id.product_price);
            image = (ImageView) itemView.findViewById(R.id.img_thumbnail);
        }
    }

}


