//
//  SingletonClass.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 01/12/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Parse/Parse.h>

@interface SingletonClass : NSObject {
    PFObject *ads;
    NSString *objectId;
    
}
@property (nonatomic, retain) PFObject *ads;
@property (nonatomic, retain) NSString *geocode;

+ (id)sharedAds;
+ (id)sharedGeocode;
@end
