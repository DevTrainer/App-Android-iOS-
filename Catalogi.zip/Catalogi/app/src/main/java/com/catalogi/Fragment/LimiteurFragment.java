package com.catalogi.Fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Switch;
import android.widget.TextView;

import com.catalogi.R;

/**
 * Created by Marwen on 15/11/2015.
 */
public class LimiteurFragment extends Fragment {

    Switch aSwitch;
    TextView textView;
    SeekBar seekBar;
    RadioGroup radioGroup;
    RadioButton petit,grand,moyen;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.limiteur_fragment, container, false);

        aSwitch = (Switch) view.findViewById(R.id.switch1);
        textView = (TextView) view.findViewById(R.id.textView2);
        seekBar = (SeekBar) view.findViewById(R.id.seekBar);
        radioGroup =(RadioGroup) view.findViewById(R.id.radiogroup);
        petit =(RadioButton) view.findViewById(R.id.petit);
        grand =(RadioButton) view.findViewById(R.id.grand);
        moyen =(RadioButton) view.findViewById(R.id.moyen);

        loadSavedPreferences();


        textView.setText("Budget: " + seekBar.getProgress() + " TND");
        aSwitch.setOnCheckedChangeListener(new OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {

                if (isChecked) {
                    aSwitch.setText("Limiting budget ON");
                    textView.setVisibility(View.VISIBLE);
                    seekBar.setVisibility(View.VISIBLE);
                    radioGroup.setVisibility(View.VISIBLE);
                    savePreferences("CheckBox_Value", true);

                } else {
                    aSwitch.setText("Limiting budget OFF");
                    textView.setVisibility(View.INVISIBLE);
                    seekBar.setVisibility(View.INVISIBLE);
                    radioGroup.setVisibility(View.INVISIBLE);
                    savePreferences("CheckBox_Value", false);

                }

            }
        });
        seekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

            int progress = 0;

            @Override
            public void onProgressChanged(SeekBar seekBar, int progresValue, boolean fromUser) {

                progress = progresValue;
                textView.setText("Budget: " + seekBar.getProgress() + " TND");

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }


            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                textView.setText("Budget: " + seekBar.getProgress() + " TND");
                savePreferences("budget", seekBar.getProgress());


            }

        });
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i) {
                    case R.id.petit:
                        seekBar.setMax(500);
                        savePreferences("max", 500);
                        break;
                    case R.id.moyen:
                        seekBar.setMax(5000);
                        savePreferences("max", 5000);
                        break;
                    case R.id.grand:
                        seekBar.setMax(10000);
                        savePreferences("max", 10000);
                        break;
                }
            }
        });


        return view;

    }

    private void loadSavedPreferences() {
        SharedPreferences sharedPreferences = PreferenceManager

                .getDefaultSharedPreferences(getActivity().getApplicationContext());

        boolean checkBoxValue = sharedPreferences.getBoolean("CheckBox_Value", false);

        int name = sharedPreferences.getInt("budget", 0);
        int max = sharedPreferences.getInt("max",500);
        if (checkBoxValue) {

            aSwitch.setChecked(true);
            textView.setVisibility(View.VISIBLE);
            seekBar.setVisibility(View.VISIBLE);
            radioGroup.setVisibility(View.VISIBLE);
        } else {

            aSwitch.setText("Limiting budget OFF");
            textView.setVisibility(View.INVISIBLE);
            seekBar.setVisibility(View.INVISIBLE);
            radioGroup.setVisibility(View.INVISIBLE);

        }

        textView.setText(name + " TND");
        seekBar.setMax(max);
        seekBar.setProgress(name);

        if(max==5000){
            moyen.setChecked(true);
        }else if(max==10000){
            grand.setChecked(true);
        }else{
            petit.setChecked(true);
        }
    }

    private void savePreferences(String key, boolean value) {

        SharedPreferences sharedPreferences = PreferenceManager

                .getDefaultSharedPreferences(getActivity().getApplicationContext());

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putBoolean(key, value);
        editor.commit();

    }

    private void savePreferences(String key, int value) {

        SharedPreferences sharedPreferences = PreferenceManager

                .getDefaultSharedPreferences(getActivity().getApplicationContext());

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt(key, value);

        editor.commit();

    }




}