//
//  ProfilViewController.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfilViewController : UIViewController
- (IBAction)SideBar:(id)sender;
@property (nonatomic, strong) NSMutableIndexSet *optionIndices;
@property (strong, nonatomic) IBOutlet UILabel *user_name;
@property (strong, nonatomic) IBOutlet UILabel *email;
@property (strong, nonatomic) IBOutlet UILabel *adresse;
@property (strong, nonatomic) IBOutlet UIImageView *profile_img;
@property (strong, nonatomic) IBOutlet UILabel *telephone;

@end
