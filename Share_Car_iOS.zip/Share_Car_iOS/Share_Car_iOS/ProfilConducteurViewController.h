//
//  ProfilConducteurViewController.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 02/12/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <MessageUI/MFMessageComposeViewController.h>
#import <UIKit/UIKit.h>

@interface ProfilConducteurViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *profile_img;
@property (strong, nonatomic) IBOutlet UILabel *userName;
@property (strong, nonatomic) IBOutlet UILabel *mail;
@property (strong, nonatomic) IBOutlet UILabel *telphone;
@property (strong, nonatomic) IBOutlet UITextView *postview;


- (IBAction)Add_To_Favoris:(id)sender;
- (IBAction)sendSMS:(id)sender;
- (IBAction)sendMAIL:(id)sender;
- (IBAction)RateConducteur:(id)sender;

@end
