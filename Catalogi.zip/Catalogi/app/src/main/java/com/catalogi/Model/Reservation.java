package com.catalogi.Model;

import com.parse.ParseObject;

/**
 * Created by Wissem on 08/11/15.
 */
public class Reservation {

    public ParseObject getReservation() {
        return reservation;
    }

    public void setReservation(ParseObject reservation) {
        this.reservation = reservation;
    }

    public ParseObject reservation;

}
