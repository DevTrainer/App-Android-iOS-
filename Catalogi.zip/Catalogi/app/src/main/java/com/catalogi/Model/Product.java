package com.catalogi.Model;

/**
 * Created by Wissem on 08/11/15.
 */
public class Product {

    public String Name;
    public String Description;
    public String Categorie;
    public int Quantite;
    public String Prix;
    public String Image;
    public String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getCategorie() {
        return Categorie;
    }

    public void setCategorie(String categorie) {
        Categorie = categorie;
    }

    public int getQuantite() {
        return Quantite;
    }

    public void setQuantite(int quantite) {
        Quantite = quantite;
    }

    public String getPrix() {
        return Prix;
    }

    public void setPrix(String prix) {
        Prix = prix;
    }

    public Boolean getPromotion() {
        return Promotion;
    }

    public void setPromotion(Boolean promotion) {
        Promotion = promotion;
    }

    public Boolean Promotion;

}
