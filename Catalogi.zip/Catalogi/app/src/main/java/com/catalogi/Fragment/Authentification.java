package com.catalogi.Fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.catalogi.R;
import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseUser;

/**
 * Created by Wissem on 29/10/15.
 */
public class Authentification extends Fragment {


    public Authentification() {
        // Required empty public constructor
    }
    private OnFragmentInteractionListener mListener;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.authentification_activity, container, false);
        Button connect  = (Button) view.findViewById(R.id.connecter);
        Button sign_up  = (Button) view.findViewById(R.id.inscription);
        final EditText username =(android.widget.EditText) view.findViewById(R.id.email_ath);
        final EditText password =(EditText) view.findViewById(R.id.pass_auth);

        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ParseUser.logInInBackground(username.getText().toString(),password.getText().toString(), new LogInCallback() {
                    public void done(ParseUser user, ParseException e) {
                        if (user != null) {
                            Toast.makeText(getActivity(),
                                    "succesfully Connected",
                                    Toast.LENGTH_SHORT).show();
                            showHomeFragment(new CatalogueFragment());
                        } else {
                            Toast.makeText(getActivity(),
                                    "Verify your Username and password" ,
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHomeFragment(new InscriptionFragment());
            }
        });

        return view;

    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
          //  mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        public void onMenuSelection(String menu_item);
    }
    public void showHomeFragment(Fragment fragment) {
        Fragment home = fragment;
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container, home)
                .addToBackStack(getClass().getSimpleName())
                .commit();
    }

}

