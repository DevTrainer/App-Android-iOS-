//
//  DetailsViewController.m
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import "DetailsViewController.h"
#import "SingletonClass.h"
#import "PAWActivityView.h"

@interface DetailsViewController ()

@end
NSString *idads;
@implementation DetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    SingletonClass* sharedSingleton = [SingletonClass sharedAds];
    PFObject *AdsSelected = [sharedSingleton ads];
    idads =  AdsSelected.objectId;
    
    _livingFrom.text = [AdsSelected objectForKey:@"livingFrom"];
    _goingTo.text = [AdsSelected objectForKey:@"goingTo"];
    _roadOn.text = [AdsSelected objectForKey:@"roadOn"];
    _date.text = [AdsSelected objectForKey:@"date"];
    _time.text = [AdsSelected objectForKey:@"time"];
    
    [self retreiveDataFromAds];
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) retreiveDataFromAds{
    
}

- (IBAction)ReserverAds:(id)sender {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Log out of Share Car?"
                                                        message:nil
                                                       delegate:self
                                              cancelButtonTitle:@"Confirm Reservation"
                                              otherButtonTitles:@"Cancel", nil];
    [alertView show];
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    PAWActivityView *activityView = [[PAWActivityView alloc] initWithFrame:self.view.bounds];
    activityView.label.text = @"Loding Reservation";
    activityView.label.font = [UIFont boldSystemFontOfSize:20.f];
    
    _activityView = activityView;
    [self.view addSubview:_activityView];
    [activityView.activityIndicator startAnimating];
    if (buttonIndex == alertView.cancelButtonIndex) {
        
        // Log out.
        PFQuery *query = [PFQuery queryWithClassName:@"ads"];
        [query getObjectInBackgroundWithId:idads block:^(PFObject *ads, NSError *error) {
            // Do something with the returned PFObject in the gameScore variable.
            
            PFObject *reservation = [PFObject objectWithClassName:@"reservation"];
            PFUser *user = [PFUser currentUser];
            reservation[@"ads"] =ads;
            reservation[@"user"] = user;
            reservation[@"placeNbr"] = @"2";
            reservation[@"bagage"] = @"small bagage";
            [reservation saveInBackground];
            [reservation saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                if (!error) {
                    [activityView.activityIndicator stopAnimating];
                    [_activityView removeFromSuperview];
                }
                else{
                    // Log details of the failure
                    NSLog(@"Error: %@ %@", error, [error userInfo]);
                }
            }];

        }];
        
    }
}
@end
