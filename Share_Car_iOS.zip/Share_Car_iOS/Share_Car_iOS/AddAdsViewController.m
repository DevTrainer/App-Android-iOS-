//
//  AddAdsViewController.m
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import "AddAdsViewController.h"
#import "PAWActivityView.h"
#import <Parse/Parse.h>
#import "SingletonClass.h"

@interface AddAdsViewController ()

@end

@implementation AddAdsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)dismissView:(id)sender {
    [[self presentingViewController] dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)ajoutAds:(id)sender {
    [self myMethod];
}
- (void)myMethod {
    self.activityViewVisible = YES;
    PFObject *ads = [PFObject objectWithClassName:@"ads"];
    ads[@"type"] = @"REQUEST";
    ads[@"livingFrom"] = _livfrom.text;
    
  
    ads[@"livingpoint"] = _LivingFrom;
    ads[@"roadOn"] = _roadOn.text;
    
  
    ads[@"r1point"] = _rOn;
    ads[@"goingTo"] = _goingTo.text;
    
    ads[@"goingpoint"] = _gTo;
    ads[@"date"] = _date.text;
    ads[@"time"] = _time.text;
    if(_bagege.selectedSegmentIndex == 0)
    {
        ads[@"carsize"] = @"Small(-5)";
    }
    else
    {
        ads[@"carsize"] = @"large(+5)";
    }
    ads[@"price"] = _price.text;
    ads[@"clim"] = @"YES";
    ads[@"fum"] = @"YES";
    ads[@"animal"] = @"YES";
    ads[@"gender"] = @"mal";
    ads[@"bagage"] = @"YES";
    ads[@"user"] = [PFUser currentUser];
    
    [ads saveInBackground];
    [ads saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        if (!error) {
            self.activityViewVisible = NO ;
            [[self presentingViewController] dismissViewControllerAnimated:YES completion:nil];
        }
        else{
            // Log details of the failure
            NSLog(@"Error: %@ %@", error, [error userInfo]);
        }
    }];
    
}
- (void)setActivityViewVisible:(BOOL)visible {
    if (self.activityViewVisible == visible) {
        return;
    }
    
    _activityViewVisible = visible;
    
    if (_activityViewVisible) {
        PAWActivityView *activityView = [[PAWActivityView alloc] initWithFrame:self.view.bounds];
        activityView.label.text = @"regestration";
        activityView.label.font = [UIFont boldSystemFontOfSize:20.f];
        [activityView.activityIndicator startAnimating];
        
        _activityView = activityView;
        [self.view addSubview:_activityView];
    } else {
        [_activityView removeFromSuperview];
        _activityView = nil;
    }
}
-(NSString *)getLongLatFromLivingFrom:(NSString*)adress{
    if(self.geocoder == nil)
    {
        self.geocoder = [[CLGeocoder alloc] init];
    }
    [self.geocoder geocodeAddressString:adress completionHandler:^(NSArray *placemarks, NSError *error) {
            if(placemarks.count > 0)
        {
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            NSArray* foo = [placemark.location.description componentsSeparatedByString: @">"];
            NSArray* foo2 = [[foo objectAtIndex: 0] componentsSeparatedByString: @"<"];
            NSArray* foo3 = [[foo2 objectAtIndex: 1] componentsSeparatedByString: @","];
            
            NSArray* foo4 = [[foo3 objectAtIndex:0] componentsSeparatedByString: @"+"];
            NSArray* foo5 = [[foo3 objectAtIndex: 1] componentsSeparatedByString: @"+"];
            
            _LivingFrom = [NSString stringWithFormat:@"%@ , %@", [foo4 objectAtIndex:1],[foo5 objectAtIndex:1
                    ]];
            SingletonClass* shared = [SingletonClass sharedGeocode];
            [shared setGeocode:_LivingFrom];
            [self setLivingFrom:_LivingFrom];
            
        }
        else if (error.domain == kCLErrorDomain)
        {
            switch (error.code)
            {
                case kCLErrorDenied:
                    _LivingFrom
                    = @"Location Services Denied by User";
                    break;
                case kCLErrorNetwork:
                    _LivingFrom = @"No Network";
                    break;
                case kCLErrorGeocodeFoundNoResult:
                    _LivingFrom = @"No Result Found";
                    break;
                default:
                    _LivingFrom = error.localizedDescription;
                    break;
            }
        }
        else
        {
            _LivingFrom = error.localizedDescription;
            
        }
    }];
    SingletonClass* shared = [SingletonClass sharedGeocode];
    _LivingFrom = [shared geocode];
    return _LivingFrom;
}
-(NSString *)getLongLatFromRoadOn:(NSString*)adress{
    if(self.geocoder == nil)
    {
        self.geocoder = [[CLGeocoder alloc] init];
    }
    [self.geocoder geocodeAddressString:adress completionHandler:^(NSArray *placemarks, NSError *error) {
        if(placemarks.count > 0)
        {
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            NSArray* foo = [placemark.location.description componentsSeparatedByString: @">"];
            NSArray* foo2 = [[foo objectAtIndex: 0] componentsSeparatedByString: @"<"];
            NSArray* foo3 = [[foo2 objectAtIndex: 1] componentsSeparatedByString: @","];
            
            NSArray* foo4 = [[foo3 objectAtIndex:0] componentsSeparatedByString: @"+"];
            NSArray* foo5 = [[foo3 objectAtIndex: 1] componentsSeparatedByString: @"+"];
            
            _rOn = [NSString stringWithFormat:@"%@ , %@", [foo4 objectAtIndex:1],[foo5 objectAtIndex:1
                                                                                       ]];
            SingletonClass* shared = [SingletonClass sharedGeocode];
            [shared setGeocode: _rOn];
            
        }
        else if (error.domain == kCLErrorDomain)
        {
            switch (error.code)
            {
                case kCLErrorDenied:
                    _rOn
                    = @"Location Services Denied by User";
                    break;
                case kCLErrorNetwork:
                     _rOn = @"No Network";
                    break;
                case kCLErrorGeocodeFoundNoResult:
                    _rOn = @"No Result Found";
                    break;
                default:
                     _rOn = error.localizedDescription;
                    break;
            }
        }
        else
        {
             _rOn = error.localizedDescription;
            
        }
    }];
    SingletonClass* shared = [SingletonClass sharedGeocode];
     _rOn = [shared geocode];
    return  _rOn;
}

-(NSString *)getLongLatFromGoingTo:(NSString*)adress{
    if(self.geocoder == nil)
    {
        self.geocoder = [[CLGeocoder alloc] init];
    }
    [self.geocoder geocodeAddressString:adress completionHandler:^(NSArray *placemarks, NSError *error) {
        if(placemarks.count > 0)
        {
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            NSArray* foo = [placemark.location.description componentsSeparatedByString: @">"];
            NSArray* foo2 = [[foo objectAtIndex: 0] componentsSeparatedByString: @"<"];
            NSArray* foo3 = [[foo2 objectAtIndex: 1] componentsSeparatedByString: @","];
            
            NSArray* foo4 = [[foo3 objectAtIndex:0] componentsSeparatedByString: @"+"];
            NSArray* foo5 = [[foo3 objectAtIndex: 1] componentsSeparatedByString: @"+"];
            
            _gTo = [NSString stringWithFormat:@"%@ , %@", [foo4 objectAtIndex:1],[foo5 objectAtIndex:1
                                                                                       ]];
            SingletonClass* shared = [SingletonClass sharedGeocode];
            [shared setGeocode:_gTo];
          
            
        }
        else if (error.domain == kCLErrorDomain)
        {
            switch (error.code)
            {
                case kCLErrorDenied:
                    _gTo
                    = @"Location Services Denied by User";
                    break;
                case kCLErrorNetwork:
                   _gTo = @"No Network";
                    break;
                case kCLErrorGeocodeFoundNoResult:
                   _gTo = @"No Result Found";
                    break;
                default:
                    _gTo = error.localizedDescription;
                    break;
            }
        }
        else
        {
           _gTo = error.localizedDescription;
            
        }
    }];
    SingletonClass* shared = [SingletonClass sharedGeocode];
    _gTo = [shared geocode];
    return _gTo;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
          [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
    
}


-(void)textFieldDidEndEditing:(UITextField *)textField
{
    if ( ![_livfrom isFirstResponder] || ![_livfrom isSelected] ) {
        //if ( [textField state] != UIControlStateSelected) {
          _LivingFrom = [self getLongLatFromLivingFrom:_livfrom.text];
        // remove view / etc...
    }
    if ( ![_roadOn isFirstResponder] || ![_roadOn isSelected] ) {
        //if ( [textField state] != UIControlStateSelected) {
         _rOn = [self getLongLatFromRoadOn:_roadOn.text];
        // remove view / etc...
    }
    if ( ![_livfrom isFirstResponder] || ![_livfrom isSelected] ) {
        //if ( [textField state] != UIControlStateSelected) {
        _gTo = [self getLongLatFromGoingTo:_goingTo.text];
        // remove view / etc...
    }
}

@end
