//
//  SignUpViewController.h
//  FBParse
//
//  Created by Wissem Rezgui on 09/11/2014.
//  Copyright (c) 2014 Toby Stephens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpViewController : UIViewController <UIImagePickerControllerDelegate>
- (IBAction)uploadImage:(id)sender;
- (IBAction)Inscription:(id)sender;



@property (strong, nonatomic) IBOutlet UITextField *lbl_name;
@property (strong, nonatomic) IBOutlet UITextField *lbl_password;
@property (strong, nonatomic) IBOutlet UITextField *lbl_mail;
@property (strong, nonatomic) IBOutlet UITextField *lbl_adress;
@property (strong, nonatomic) IBOutlet UITextField *tel;
- (IBAction)chose_image:(id)sender;
@property (strong, nonatomic) IBOutlet UIImageView *img;
- (IBAction)retreive:(id)sender;
- (IBAction)dismiss_view:(id)sender;


@end
