//
//  Ads.h
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 28/11/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Ads : NSObject

@property (nonatomic, strong) NSString *LivingFrom; // name of recipe
@property (nonatomic, strong) NSString *roadOn; // preparation time
@property (nonatomic, strong) NSString *goingTo; // image filename of recipe
@property (nonatomic, strong) NSString *date; // image filename of recipe
@property (nonatomic, strong) NSString *time; // image filename of recipe

@end
