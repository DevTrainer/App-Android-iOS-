//
//  SingletonClass.m
//  Share_Car_iOS
//
//  Created by Wissem Rezgui on 01/12/2014.
//  Copyright (c) 2014 Wissem Rezgui. All rights reserved.
//

#import "SingletonClass.h"

@implementation SingletonClass
@synthesize ads;
@synthesize geocode;

#pragma mark Singleton Methods

+ (id)sharedAds {
    static SingletonClass *sharedMyAds = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMyAds = [[self alloc] init];
    });
    return sharedMyAds;
}

+ (id)sharedGeocode {
    static SingletonClass *sharedGeocode = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedGeocode = [[self alloc] init];
    });
    return sharedGeocode;
}

- (id)init {
    if (self = [super init]) {
    }
    return self;
}

- (void)dealloc {
    // Should never be called, but just here for clarity really.
}

@end
